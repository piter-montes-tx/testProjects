Given(/^I clear calculator results$/) do
  xpath("//android.widget.Button[@resource-id = \"com.android.calculator2:id/del\"]").click
end

And(/^I click Equal$/) do
  xpath("//android.widget.Button[@resource-id = \"com.android.calculator2:id/equal\"]").click
end

When(/^I type in (.*) \+ (.*)$/) do |number1, number2|
  xpath("//android.widget.Button[@resource-id = \"com.android.calculator2:id/digit#{number1}\"]").click
  xpath("//android.widget.Button[@resource-id = \"com.android.calculator2:id/plus\"]").click
  xpath("//android.widget.Button[@resource-id = \"com.android.calculator2:id/digit#{number2}\"]").click
end

Then(/^I should see (.*) as result$/) do |result|
  res = xpath("//android.widget.EditText[@index=\"0\"]").text
  expected = "#{result}"
  expect(res).to eq(expected)
end